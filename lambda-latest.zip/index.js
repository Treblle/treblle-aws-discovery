const AWS = require('aws-sdk');
const https = require('https');
const util = require('util');

// Configuration
const DISCOVERY_ENDPOINT = 'https://autodiscovery.treblle.com/api/v1/aws';
const BATCH_SIZE = 50; // Number of APIs to send per batch
const CROSS_ACCOUNT_ROLE_NAME = process.env.CROSS_ACCOUNT_ROLE_NAME || 'TreblleDiscoveryRole';
const TREBLLE_SDK_TOKEN = process.env.TREBLLE_SDK_TOKEN;

// Initialize AWS clients
const organizations = new AWS.Organizations();
const sts = new AWS.STS();

exports.handler = async (event) => {
    console.log('Starting API Gateway discovery...');
    
    // Validate required environment variables
    if (!TREBLLE_SDK_TOKEN) {
        console.error('TREBLLE_SDK_TOKEN environment variable is required');
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'Configuration error',
                message: 'TREBLLE_SDK_TOKEN environment variable is required'
            })
        };
    }
    
    try {
        // Get all accounts in the organization
        const accounts = await getAllAccounts();
        console.log(`Found ${accounts.length} accounts in organization`);
        
        // Get all regions where API Gateway is available
        const regions = await getApiGatewayRegions();
        console.log(`Will scan ${regions.length} regions`);
        
        let totalApis = 0;
        const allApis = [];
        
        // Scan each account and region
        for (const account of accounts) {
            for (const region of regions) {
                try {
                    console.log(`Scanning account ${account.Id} in region ${region}...`);
                    
                    // Get credentials for cross-account access
                    const credentials = await assumeRole(account.Id, region);
                    
                    // Discover APIs in this account/region
                    const apis = await discoverApisInAccount(account.Id, region, credentials);
                    allApis.push(...apis);
                    totalApis += apis.length;
                    
                    console.log(`Found ${apis.length} APIs in ${account.Id}/${region}`);
                    
                } catch (error) {
                    console.error(`Error scanning ${account.Id}/${region}:`, error.message);
                    // Continue with other accounts/regions
                }
            }
        }
        
        console.log(`Total APIs discovered: ${totalApis}`);
        
        // Send APIs in batches to discovery endpoint
        if (allApis.length > 0) {
            await sendApisInBatches(allApis);
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'API discovery completed successfully',
                totalApis: totalApis,
                accountsScanned: accounts.length,
                regionsScanned: regions.length
            })
        };
        
    } catch (error) {
        console.error('Error in API discovery:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'API discovery failed',
                message: error.message
            })
        };
    }
};

// Get all accounts in the organization
async function getAllAccounts() {
    try {
        const result = await organizations.listAccounts().promise();
        return result.Accounts.filter(account => account.Status === 'ACTIVE');
    } catch (error) {
        console.error('Error getting organization accounts:', error);
        throw error;
    }
}

// Get regions where API Gateway is available
async function getApiGatewayRegions() {
    // Common regions where API Gateway is available
    // You can extend this list or make it dynamic
    return [
        'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
        'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
        'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1',
        'ap-northeast-2', 'ap-south-1', 'ca-central-1',
        'sa-east-1'
    ];
}

// Assume role in target account
async function assumeRole(accountId, region) {
    const roleArn = `arn:aws:iam::${accountId}:role/${CROSS_ACCOUNT_ROLE_NAME}`;
    
    try {
        const result = await sts.assumeRole({
            RoleArn: roleArn,
            RoleSessionName: `APIGatewayDiscovery-${Date.now()}`
        }).promise();
        
        return {
            accessKeyId: result.Credentials.AccessKeyId,
            secretAccessKey: result.Credentials.SecretAccessKey,
            sessionToken: result.Credentials.SessionToken
        };
    } catch (error) {
        console.error(`Error assuming role in account ${accountId}:`, error.message);
        throw error;
    }
}

// Discover APIs in a specific account and region
async function discoverApisInAccount(accountId, region, credentials) {
    const apis = [];
    
    // Initialize API Gateway clients with assumed role credentials
    const apiGateway = new AWS.APIGateway({
        region: region,
        credentials: credentials
    });
    
    const apiGatewayV2 = new AWS.ApiGatewayV2({
        region: region,
        credentials: credentials
    });
    
    try {
        // Discover REST APIs
        const restApis = await discoverRestApis(apiGateway, accountId, region);
        apis.push(...restApis);
        
        // Discover HTTP APIs
        const httpApis = await discoverHttpApis(apiGatewayV2, accountId, region);
        apis.push(...httpApis);
        
    } catch (error) {
        console.error(`Error discovering APIs in ${accountId}/${region}:`, error.message);
        throw error;
    }
    
    return apis;
}

// Discover REST APIs
async function discoverRestApis(apiGateway, accountId, region) {
    const apis = [];
    let position = null;
    
    do {
        try {
            const params = {
                limit: 500
            };
            if (position) {
                params.position = position;
            }
            
            const result = await apiGateway.getRestApis(params).promise();
            
            for (const api of result.items) {
                // Get stages for this API
                const stages = await getRestApiStages(apiGateway, api.id);
                
                // Build endpoint URL
                const endpoint = `https://${api.id}.execute-api.${region}.amazonaws.com`;
                
                apis.push({
                    accountId: accountId,
                    region: region,
                    apiId: api.id,
                    apiName: api.name,
                    apiType: 'REST',
                    stages: stages,
                    endpoint: endpoint
                });
            }
            
            position = result.position;
            
        } catch (error) {
            console.error(`Error getting REST APIs:`, error.message);
            break;
        }
        
    } while (position);
    
    return apis;
}

// Discover HTTP APIs
async function discoverHttpApis(apiGatewayV2, accountId, region) {
    const apis = [];
    let nextToken = null;
    
    do {
        try {
            const params = {
                MaxResults: '500'
            };
            if (nextToken) {
                params.NextToken = nextToken;
            }
            
            const result = await apiGatewayV2.getApis(params).promise();
            
            for (const api of result.Items) {
                // Get stages for this API
                const stages = await getHttpApiStages(apiGatewayV2, api.ApiId);
                
                // Build endpoint URL
                const endpoint = `https://${api.ApiId}.execute-api.${region}.amazonaws.com`;
                
                apis.push({
                    accountId: accountId,
                    region: region,
                    apiId: api.ApiId,
                    apiName: api.Name,
                    apiType: 'HTTP',
                    stages: stages,
                    endpoint: endpoint
                });
            }
            
            nextToken = result.NextToken;
            
        } catch (error) {
            console.error(`Error getting HTTP APIs:`, error.message);
            break;
        }
        
    } while (nextToken);
    
    return apis;
}

// Get stages for REST API
async function getRestApiStages(apiGateway, apiId) {
    try {
        const result = await apiGateway.getStages({
            restApiId: apiId
        }).promise();
        
        return result.item.map(stage => stage.stageName);
    } catch (error) {
        console.error(`Error getting stages for REST API ${apiId}:`, error.message);
        return [];
    }
}

// Get stages for HTTP API
async function getHttpApiStages(apiGatewayV2, apiId) {
    try {
        const result = await apiGatewayV2.getStages({
            ApiId: apiId
        }).promise();
        
        return result.Items.map(stage => stage.StageName);
    } catch (error) {
        console.error(`Error getting stages for HTTP API ${apiId}:`, error.message);
        return [];
    }
}

// Send APIs to discovery endpoint in batches
async function sendApisInBatches(apis) {
    const batches = [];
    
    // Split APIs into batches
    for (let i = 0; i < apis.length; i += BATCH_SIZE) {
        batches.push(apis.slice(i, i + BATCH_SIZE));
    }
    
    console.log(`Sending ${apis.length} APIs in ${batches.length} batches`);
    
    // Send each batch
    for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];
        console.log(`Sending batch ${i + 1}/${batches.length} with ${batch.length} APIs`);
        
        try {
            await sendApisBatch(batch);
            console.log(`Successfully sent batch ${i + 1}`);
        } catch (error) {
            console.error(`Error sending batch ${i + 1}:`, error.message);
            // Continue with other batches
        }
        
        // Small delay between batches to avoid overwhelming the endpoint
        if (i < batches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }
}

// Send a single batch of APIs
async function sendApisBatch(apis) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify(apis);
        
        const options = {
            hostname: 'autodiscovery.treblle.com',
            port: 443,
            path: '/api/v1/aws',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData),
                'x-api-key': TREBLLE_SDK_TOKEN,
                'User-Agent': 'Treblle-AWS-Discovery/1.0'
            }
        };
        
        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    resolve(data);
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${data}`));
                }
            });
        });
        
        req.on('error', (error) => {
            reject(error);
        });
        
        req.write(postData);
        req.end();
    });
}